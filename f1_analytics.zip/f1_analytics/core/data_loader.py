"""
core/data_loader.py

Capa de acceso a datos sobre FastF1. Centraliza:
- Configuración de caché
- Carga de sesiones (Q, R, Sprint, Practice)
- Funciones de utilidad para listar pilotos, eventos y temporadas

Todas las páginas de Streamlit deben pasar por aquí en lugar de
llamar a fastf1 directamente, para mantener una única fuente de verdad
y poder cambiar de implementación sin tocar la UI.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import fastf1
import pandas as pd
import streamlit as st

# ---------------------------------------------------------------------------
# Configuración de caché de FastF1
# ---------------------------------------------------------------------------
# FastF1 descarga datos pesados (telemetría, vueltas, clima...) desde la API
# de F1. Activar la caché evita re-descargar lo mismo en cada rerun de
# Streamlit. Aun si el usuario no quiere preocuparse por la gestión manual
# de la caché, mantenerla activada por defecto evita una app inutilizable
# (Streamlit relanza el script en cada interacción).
CACHE_DIR = Path(__file__).resolve().parent.parent / ".fastf1_cache"
CACHE_DIR.mkdir(exist_ok=True)
fastf1.Cache.enable_cache(str(CACHE_DIR))


# Mapeo de tipos de sesión "amigables" -> identificador que espera FastF1
SESSION_TYPES = {
    "Clasificación": "Q",
    "Carrera": "R",
    "Sprint": "S",
    "Clasificación Sprint": "SQ",
    "Libres 1": "FP1",
    "Libres 2": "FP2",
    "Libres 3": "FP3",
}


@st.cache_data(show_spinner=False)
def get_available_seasons() -> list[int]:
    """Devuelve un rango razonable de temporadas soportadas por FastF1."""
    # FastF1 tiene datos de telemetría fiables desde 2018 en adelante.
    current_year = pd.Timestamp.now().year
    return list(range(current_year, 2017, -1))


@st.cache_data(show_spinner="Cargando calendario de la temporada...")
def get_event_schedule(year: int) -> pd.DataFrame:
    """Devuelve el calendario de Grandes Premios de una temporada."""
    schedule = fastf1.get_event_schedule(year, include_testing=False)
    return schedule[["RoundNumber", "EventName", "Location", "Country", "EventDate"]]


@st.cache_data(show_spinner="Cargando datos de la sesión... (puede tardar un poco)")
def load_session(year: int, gp: str, session_type: str) -> fastf1.core.Session:
    """
    Carga una sesión completa (vueltas, telemetría, resultados, clima).

    Parameters
    ----------
    year : int
        Temporada, p.ej. 2024
    gp : str
        Nombre o identificador del Gran Premio (acepta nombre, país o número de ronda)
    session_type : str
        Código de sesión: "Q", "R", "S", "SQ", "FP1", "FP2", "FP3"
    """
    session = fastf1.get_session(year, gp, session_type)
    session.load()
    return session


def get_drivers_in_session(session: fastf1.core.Session) -> pd.DataFrame:
    """
    Devuelve un DataFrame con los pilotos que participaron en la sesión,
    incluyendo código de 3 letras, nombre completo y equipo.
    """
    results = session.results[["Abbreviation", "FullName", "TeamName"]].copy()
    results = results.dropna(subset=["Abbreviation"]).reset_index(drop=True)
    return results


def get_driver_color(session: fastf1.core.Session, driver_code: str) -> str:
    """Devuelve el color oficial de equipo de un piloto para usar en gráficos."""
    try:
        return fastf1.plotting.get_driver_color(driver_code, session=session)
    except Exception:
        return "#1f77b4"  # color de fallback neutro


def get_fastest_lap(session: fastf1.core.Session, driver_code: str):
    """Devuelve la vuelta más rápida de un piloto en la sesión dada."""
    driver_laps = session.laps.pick_drivers(driver_code)
    if driver_laps.empty:
        return None
    return driver_laps.pick_fastest()
